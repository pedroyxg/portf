import { Header } from '@/app/components/Header';
import { IntroCard } from '@/app/components/IntroCard';
import { LayersCard } from '@/app/components/LayersCard';
import { MusicCard } from '@/app/components/MusicCard';
import { ImageCard } from '@/app/components/ImageCard';

export default function App() {
  return (
    <div className="relative min-h-screen bg-black">
      {/* Animated stars background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="stars" />
      </div>

      {/* Header */}
      <Header />

      {/* Main Content */}
      <div className="relative mx-auto max-w-6xl px-6 pb-20 pt-32">
        {/* Bento Grid */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* Intro Card - spans 1 column on all screens */}
          <div className="lg:row-span-2">
            <IntroCard />
          </div>

          {/* Layers Card - positioned next to Intro Card */}
          <div className="lg:col-span-2 lg:row-span-2">
            <LayersCard />
          </div>

          {/* Music Card - spans full width on mobile, 2 cols on medium+ */}
          <div className="md:col-span-2 lg:col-span-2">
            <MusicCard />
          </div>

          {/* Image Card 1 */}
          <div className="aspect-square">
            <ImageCard 
              imageUrl="https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?w=400&h=400&fit=crop"
              alt="Design project"
            />
          </div>

          {/* Image Card 2 */}
          <div className="aspect-square">
            <ImageCard 
              imageUrl="https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?w=400&h=400&fit=crop"
              alt="Creative work"
            />
          </div>

          {/* Image Card 3 */}
          <div className="aspect-square">
            <ImageCard 
              imageUrl="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=400&h=400&fit=crop"
              alt="Portfolio piece"
            />
          </div>
        </div>
      </div>

      <style>{`
        .stars {
          position: absolute;
          width: 100%;
          height: 100%;
          background: transparent;
        }
        
        .stars::before,
        .stars::after {
          content: '';
          position: absolute;
          width: 2px;
          height: 2px;
          background: white;
          border-radius: 50%;
          box-shadow: 
            100px 200px white,
            200px 100px white,
            300px 300px white,
            400px 150px white,
            500px 250px white,
            600px 100px white,
            700px 300px white,
            800px 200px white,
            900px 350px white,
            150px 350px white,
            250px 450px white,
            350px 150px white,
            450px 400px white,
            550px 300px white,
            650px 450px white,
            750px 150px white,
            850px 400px white,
            950px 250px white,
            50px 450px white,
            180px 280px white,
            280px 380px white,
            380px 180px white,
            480px 330px white,
            580px 230px white,
            680px 380px white,
            780px 180px white,
            880px 330px white;
        }
        
        .stars::after {
          width: 1px;
          height: 1px;
          opacity: 0.6;
          box-shadow: 
            120px 220px white,
            220px 120px white,
            320px 320px white,
            420px 170px white,
            520px 270px white,
            620px 120px white,
            720px 320px white,
            820px 220px white,
            920px 370px white,
            170px 370px white,
            270px 470px white,
            370px 170px white,
            470px 420px white,
            570px 320px white,
            670px 470px white,
            770px 170px white,
            870px 420px white,
            970px 270px white;
        }
      `}</style>
    </div>
  );
}