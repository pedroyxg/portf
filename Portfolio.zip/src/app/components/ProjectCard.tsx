import { ArrowUpRight } from 'lucide-react';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

interface ProjectCardProps {
  title: string;
  description: string;
  tags: string[];
  imageUrl: string;
  size?: 'default' | 'large';
}

export function ProjectCard({ title, description, tags, imageUrl, size = 'default' }: ProjectCardProps) {
  return (
    <div 
      className={`group relative overflow-hidden rounded-2xl bg-zinc-900/50 backdrop-blur-sm transition-all duration-300 hover:scale-[1.02] hover:bg-zinc-800/50 ${
        size === 'large' ? 'md:col-span-2' : ''
      }`}
    >
      <div className="aspect-[4/3] overflow-hidden">
        <ImageWithFallback 
          src={imageUrl}
          alt={title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
      </div>
      
      <div className="border-t border-zinc-800 p-6">
        <div className="mb-3 flex items-start justify-between">
          <h3 className="text-xl text-white">{title}</h3>
          <ArrowUpRight className="h-5 w-5 text-zinc-500 transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-white" />
        </div>
        
        <p className="mb-4 text-sm text-zinc-400">{description}</p>
        
        <div className="flex flex-wrap gap-2">
          {tags.map((tag) => (
            <span 
              key={tag}
              className="rounded-full bg-zinc-800/50 px-3 py-1 text-xs text-zinc-300"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
      
      <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10" />
    </div>
  );
}
