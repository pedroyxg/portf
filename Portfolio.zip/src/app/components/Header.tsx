import { useRef, useState, useEffect } from 'react';
import { gsap } from 'gsap';
import { GoArrowUpRight } from 'react-icons/go';
import { Hand } from 'lucide-react';
import { motion } from 'motion/react';

const contactLinks = [
  { label: 'Email', href: 'mailto:draxnight.py@gmail.com' },
  { label: 'Instagram', href: 'https://instagram.com/pedroyxg' },
  { label: 'GitHub', href: 'https://github.com/pedroyxg' },
  { label: 'X', href: 'https://twitter.com' }
];

export function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const navRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  // Calculate dynamic height
  const getExpandedHeight = () => {
    if (contentRef.current) {
      return 60 + contentRef.current.scrollHeight;
    }
    return 300;
  };

  const toggleMenu = () => {
    const nextState = !isOpen;
    setIsOpen(nextState);

    if (nextState) {
      // Open animation
      gsap.to(navRef.current, {
        height: getExpandedHeight(),
        duration: 0.5,
        ease: 'power4.inOut'
      });
      gsap.to(cardsRef.current, {
        y: 0,
        opacity: 1,
        stagger: 0.1,
        duration: 0.4,
        delay: 0.2
      });
    } else {
      // Close animation
      gsap.to(navRef.current, {
        height: 60,
        duration: 0.5,
        ease: 'power4.inOut'
      });
      gsap.to(cardsRef.current, {
        y: 20,
        opacity: 0,
        duration: 0.2
      });
    }
  };

  return (
    <header className="fixed left-1/2 top-6 z-50 w-full max-w-2xl -translate-x-1/2 px-6">
      <nav 
        ref={navRef} 
        className="overflow-hidden bg-zinc-900/95 backdrop-blur-xl rounded-[20px] shadow-xl"
        style={{ height: '60px' }}
      >
        {/* Top Bar */}
        <div className="flex items-center justify-between px-3 py-2.5 sm:px-6 sm:py-3.5 relative z-10">
          <div className="flex items-center justify-start w-16 sm:w-20">
            <button 
              onClick={toggleMenu}
              className="text-white transition-colors hover:text-zinc-300 active:scale-95 transition-transform"
            >
              <motion.div
                animate={{
                  rotate: isOpen ? 0 : [0, 14, -8, 14, -4, 10, 0],
                }}
                transition={{
                  duration: 0.5,
                  repeat: isOpen ? 0 : Infinity,
                  repeatDelay: 2,
                }}
              >
                <Hand className="h-4 w-4 sm:h-5 sm:w-5" />
              </motion.div>
            </button>
          </div>
          
          <h1 className="text-white font-medium text-sm sm:text-base absolute left-1/2 -translate-x-1/2">
            Pedro Yong
          </h1>
          
          <div className="flex items-center justify-end w-16 sm:w-20">
            <a 
              href="#docs" 
              className="text-white transition-colors hover:text-zinc-300 font-medium text-sm sm:text-base active:scale-95 transition-transform"
            >
              Docs
            </a>
          </div>
        </div>

        {/* Expandable Content */}
        <div 
          ref={contentRef}
          className="px-6 pb-6"
          style={{ 
            opacity: isOpen ? 1 : 0, 
            pointerEvents: isOpen ? 'auto' : 'none' 
          }}
        >
          <div 
            ref={el => cardsRef.current[0] = el}
            className="rounded-2xl bg-zinc-800/50 p-4"
            style={{ opacity: 0, transform: 'translateY(20px)' }}
          >
            <div className="mb-3 text-sm font-medium text-zinc-400">Contact</div>
            <div className="grid grid-cols-2 gap-2">
              {contactLinks.map((link, i) => (
                <a
                  key={i}
                  href={link.href}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 rounded-lg bg-zinc-700/50 px-3 py-2 text-sm text-white transition-colors hover:bg-zinc-700"
                >
                  <GoArrowUpRight className="h-4 w-4" />
                  {link.label}
                </a>
              ))}
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
}