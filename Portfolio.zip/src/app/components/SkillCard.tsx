import { LucideIcon } from 'lucide-react';

interface SkillCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

export function SkillCard({ icon: Icon, title, description }: SkillCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-2xl bg-zinc-900/50 p-6 backdrop-blur-sm transition-all duration-300 hover:bg-zinc-800/50">
      <div className="mb-4 inline-flex rounded-xl bg-zinc-800/50 p-3">
        <Icon className="h-6 w-6 text-zinc-300" />
      </div>
      
      <h3 className="mb-2 text-lg text-white">{title}</h3>
      <p className="text-sm text-zinc-400">{description}</p>
      
      <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10" />
    </div>
  );
}
