export function HeroSection() {
  return (
    <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-zinc-900 to-zinc-950 p-12 md:p-16 lg:p-20">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(120,119,198,0.15),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(74,222,128,0.1),transparent_50%)]" />
      
      <div className="relative z-10 max-w-4xl">
        <div className="mb-6 inline-block rounded-full bg-zinc-800/50 px-4 py-2 backdrop-blur-sm">
          <p className="text-sm text-zinc-400">Creative Developer</p>
        </div>
        
        <h1 className="mb-6 text-5xl md:text-6xl lg:text-7xl">
          <span className="bg-gradient-to-r from-white to-zinc-400 bg-clip-text text-transparent">
            Crafting Digital
          </span>
          <br />
          <span className="bg-gradient-to-r from-white to-zinc-400 bg-clip-text text-transparent">
            Experiences
          </span>
        </h1>
        
        <p className="mb-8 max-w-2xl text-lg text-zinc-400 md:text-xl">
          Blending creativity with code to build immersive web experiences that push the boundaries of what's possible.
        </p>
        
        <div className="flex flex-wrap gap-4">
          <button className="group relative overflow-hidden rounded-full bg-white px-8 py-3 text-zinc-900 transition-all hover:scale-105">
            <span className="relative z-10">View Projects</span>
          </button>
          <button className="rounded-full border border-zinc-700 bg-zinc-900/50 px-8 py-3 text-white backdrop-blur-sm transition-all hover:border-zinc-600 hover:bg-zinc-800/50">
            Get in Touch
          </button>
        </div>
      </div>
    </section>
  );
}
