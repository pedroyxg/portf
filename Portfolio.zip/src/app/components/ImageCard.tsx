import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

interface ImageCardProps {
  imageUrl: string;
  alt: string;
}

export function ImageCard({ imageUrl, alt }: ImageCardProps) {
  return (
    <div className="overflow-hidden rounded-3xl border border-zinc-800">
      <ImageWithFallback 
        src={imageUrl}
        alt={alt}
        className="h-full w-full object-cover"
      />
    </div>
  );
}
