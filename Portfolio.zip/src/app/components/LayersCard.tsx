import { ExternalLink } from 'lucide-react';

export function LayersCard() {
  return (
    <div className="group relative h-full overflow-hidden rounded-3xl bg-gradient-to-br from-fuchsia-600 to-purple-700 p-8">
      <div className="absolute right-8 top-8 flex h-32 w-32 items-center justify-center">
        <div className="absolute h-24 w-24 rounded-2xl bg-white/90 shadow-2xl" />
        <div className="absolute -translate-x-2 -translate-y-2 h-24 w-24 rounded-2xl bg-white/70" />
        <div className="absolute -translate-x-4 -translate-y-4 h-24 w-24 rounded-2xl bg-white/50" />
      </div>
      
      <div className="absolute bottom-8 left-8">
        <h3 className="mb-1 text-2xl text-white">Layers</h3>
        <p className="text-purple-200">A home for designers</p>
      </div>
      
      <div className="absolute bottom-8 right-8">
        <ExternalLink className="h-5 w-5 text-white" />
      </div>
    </div>
  );
}