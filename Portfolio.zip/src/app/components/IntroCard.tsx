import { Flower2 } from 'lucide-react';

export function IntroCard() {
  return (
    <div className="flex h-full flex-col justify-between rounded-3xl border border-zinc-800 bg-zinc-900/50 p-8 backdrop-blur-sm">
      <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-purple-600">
        <Flower2 className="h-6 w-6 text-white" />
      </div>
      
      <div className="flex-1">
        <h2 className="mb-4 text-4xl text-white">Liam</h2>
        
        <p className="mb-6 text-zinc-400">
          I'm a designer based in London, UK currently building{' '}
          <span className="text-white">layers.to</span> and running{' '}
          <span className="text-white">codeandwander.com</span>.
        </p>
        
        <button className="rounded-full bg-white px-6 py-2 text-sm text-zinc-900 transition-transform hover:scale-105">
          FOLLOW ME
        </button>
      </div>
    </div>
  );
}
