import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

export function MusicCard() {
  return (
    <div className="flex items-center gap-4 rounded-3xl border border-green-900/50 bg-gradient-to-br from-green-950 to-green-900 p-6">
      <div className="h-12 w-12 overflow-hidden rounded-lg bg-white">
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=100&h=100&fit=crop"
          alt="Album art"
          className="h-full w-full object-cover"
        />
      </div>
      
      <div className="flex-1">
        <p className="text-sm text-zinc-400">Curtis Mayfield</p>
        <p className="text-white">Move On Up – Extended</p>
      </div>
      
      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-500">
        <svg className="h-4 w-4 text-white" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/>
        </svg>
      </div>
    </div>
  );
}
